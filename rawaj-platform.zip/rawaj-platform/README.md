# Rawaj CV Builder Platform

منصة رَواج لإنشاء وتعديل وتحميل السير الذاتية.

## التشغيل المحلي
npm install
npm run dev

## النشر على Vercel
ارفع الملفات إلى GitHub ثم اربط المستودع مع Vercel.
